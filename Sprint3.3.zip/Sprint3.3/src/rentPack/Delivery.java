/*Name: Tyrell Walrond
Course: CSC 243
Instructor: Professor Demarco
Filename: Delivery.java
Purpose: The purpose of this file is to contain and construct a delivery service class for 
		object orientation for a ficticious vacation resort*/

package rentPack;
import java.util.*;
import java.lang.*;


public class Delivery{
	
	double deliveryCharge;
	char site;
	Scanner in = new Scanner(System.in);
	RentObj objCall = new RentObj();
	
	Delivery(){}
	public void deliverySite(){
		
		System.out.println("Select delivery a site: ");
	       System.out.println("a. Victoria Vacation Venue\n" + "b. Bella's Beach\n" + "c. Griffin's Grove");
	       site = in.next().charAt(0);
	      
		       if(site == 'a'){
			       
			       objCall.setDelivery(0);
			       objCall.setTotalCost((float)(objCall.getTotalCost() + objCall.getDelivery()));
			      
		       }
			if(site == 'b'){
				
			       objCall.setDelivery(10);
			       objCall.setTotalCost((float)(objCall.getTotalCost() + objCall.getDelivery()));
			       
			}
			if(site == 'c'){
				objCall.setDelivery(20);
				objCall.setTotalCost((float)(objCall.getTotalCost() + objCall.getDelivery()));
				
	       }
		
	}
}